//
//  ACBAudioDeviceManager.h
//  client_sdk
//
//  Created by Jonathan Ellis on 04/05/2017.
//  Copyright © 2017 CafeX. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

typedef NS_ENUM(NSInteger, ACBAudioDevice)
{
    ACBAudioDeviceSpeakerphone,
    ACBAudioDeviceWiredHeadset,
    ACBAudioDeviceEarpiece,
    ACBAudioDeviceBluetooth,
    ACBAudioDeviceNone
};

@interface ACBAudioDeviceManager : NSObject
- (void) start;
- (void) stop;
- (void) setDefaultAudio: (ACBAudioDevice) device;
- (BOOL) setAudioDevice: (ACBAudioDevice) device;
- (void) refreshSpeakerphoneSetting;
- (ACBAudioDevice) selectedAudioDevice;
- (NSMutableArray*) audioDevices;
@end


